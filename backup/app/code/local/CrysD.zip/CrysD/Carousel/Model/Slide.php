<?php
/**
 * Slide model
 */
class CrysD_Carousel_Model_Slide extends Mage_Core_Model_Abstract
{
    protected function _construct()
    {
        $this->_init('carousel/slide');
    }
}
