<?php
/**
 * Resource model for Slide
 */
class CrysD_Carousel_Model_Mysql4_Slide extends Mage_Core_Model_Resource_Db_Abstract
{
    protected function _construct()
    {
        // table name, primary key
        $this->_init('carousel/slide', 'slide_id');
    }

    /**
     * Save all slides for a given carousel, inserting/updating/deleting as needed.
     *
     * @param CrysD_Carousel_Model_Carousel $carousel
     * @param array $slidesData  Array of slide-data arrays from POST
     */
    public function saveSlides(CrysD_Carousel_Model_Carousel $carousel, array $slidesData)
    {
        $adapter    = $this->_getWriteAdapter();
        $table      = $this->getMainTable();
        $carouselId = (int)$carousel->getId();

        // fetch existing IDs
        $existing = $adapter->fetchCol(
            $adapter->select()
                ->from($table, 'slide_id')
                ->where('carousel_id = ?', $carouselId)
        );

        $keep = [];
        foreach ($slidesData as $position => $slideData) {
            $data = [
                'carousel_id'      => $carouselId,
                'position'         => (int)$position,
                'slide_headline'   => isset($slideData['slide_headline']) ? $slideData['slide_headline'] : null,
                'slide_subheadline'=> isset($slideData['slide_subheadline'])? $slideData['slide_subheadline']: null,
                'slide_body'       => isset($slideData['slide_body'])       ? $slideData['slide_body']       : null,
                'slide_link'       => isset($slideData['slide_link'])       ? $slideData['slide_link']       : null,
                'slide_theme'      => isset($slideData['slide_theme'])      ? $slideData['slide_theme']      : null,
            ];

            if (!empty($slideData['slide_id'])) {
                // update existing
                $adapter->update(
                    $table,
                    $data,
                    ['slide_id = ?' => (int)$slideData['slide_id']]
                );
                $keep[] = (int)$slideData['slide_id'];
            } else {
                // insert new
                $adapter->insert($table, $data);
                $keep[] = (int)$adapter->lastInsertId($table);
            }
        }

        // delete slides removed in the UI
        $toDelete = array_diff($existing, $keep);
        if (!empty($toDelete)) {
            $adapter->delete($table, ['slide_id IN (?)' => $toDelete]);
        }
    }
}
